public class Main2 {

    public static void main(String[] args) {
        String mystring = "This is a test";
        System.out.println(mystring.matches("\\w.*"));

        System.out.println(mystring);
        mystring = mystring.replaceAll(" ", "");
        System.out.println(mystring);
        System.out.println("----------------------");
        String myequation = "3+6 * 6 / (4 +1)^ 2";
        System.out.println(myequation);
        if (!myequation.matches("^[0-9+-/\\*\\(\\)\\^ ]*$")) 
        {
            System.out.println("Not Correct equation");
        } 
        else 
        {
            System.out.println("Correct equation");
        }
        myequation = "3+6 * 6 / (4 +1)^ $A";
        System.out.println("----------------------");
        System.out.println(myequation);
        if (!myequation.matches("^[0-9+-/\\*\\(\\)^ ]*$")) 
        {
            System.out.println("Not Correct equation");
        } else 
        {
            System.out.println("Correct equation");
        }
    }
}
