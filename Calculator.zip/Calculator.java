import java.util.Stack;
import java.util.Scanner;

public class Calculator
{
  public static void main (String[] args)
  {
    char operator;
    Double num1, num2, answer;

    Scanner sc = new Scanner(System.in);

    //Ask user to pick an operation of their choice
    System.out.println("What operation do you want to do?: +(add), -(substract), *(multiply),or /(divide) ");
    operator = sc.next().charAt(0);


    //Have user pick the numbers they want to use
    System.out.println("Enter number");
    num1 = sc.nextDouble();

    System.out.println("Enter number");
    num2 = sc.nextDouble();


  //Sub-section for operations
    switch(operator)
      {
          //This operation adds the two numbers
          case'+':
          answer = num1 + num2;
          System.out.println(num1 + "+" + num2 + "=" + answer);
          break;

          //This operation subtracts the two numbers
          case'-':
          answer = num1 - num2;
          System.out.println(num1 + "-" + num2 + "=" + answer);
          break;

          //This operation multiplies the two numbers
          case'*':
          answer = num1 * num2;
          System.out.println(num1 + "*" + num2 + "=" + answer);
          break;

          //This operation divides the two numbers
          case'/':
          answer = num1 / num2;
          System.out.println(num1 + "/" + num2 + "=" + answer);
          break;
        
        //Detects if there are any invalid inputs
        default:
          System.out.println("Invalid operator ):");
          break;
      }
    
    sc.close();
  }
}